/*
 * MOTOR ESP32  — Non-blocking rewrite
 * - 28BYJ-48 steppers via direct GPIO (no Stepper library)
 * - ESP-NOW receives Command structs from sensor ESP32
 * - loop() never blocks → callbacks fire freely mid-motion
 *
 * SETUP:
 * 1. Upload this first
 * 2. Open Serial Monitor at 115200
 * 3. Copy the MAC address printed → paste into MOTOR_MAC in sensor_esp32.ino
 *
 * WIRING - Motor A (left):
 *   IN1 -> GPIO 25
 *   IN2 -> GPIO 26
 *   IN3 -> GPIO 27
 *   IN4 -> GPIO 14
 *
 * WIRING - Motor B (right):
 *   IN1 -> GPIO 5
 *   IN2 -> GPIO 19
 *   IN3 -> GPIO 15
 *   IN4 -> GPIO 18
 */

#include <esp_now.h>
#include <WiFi.h>

enum Dir { STOP, FWD, BWD, LEFT, RIGHT };

struct Command {
  Dir   dir;
  int   steps;
  float yaw;
  float lat;
  float lng;
  float speed;
};

const uint8_t A_PINS[4] = {25, 26, 27, 14};
const uint8_t B_PINS[4] = { 5, 19, 15, 18};

const uint8_t HALF_STEP[8][4] = {
  {1,0,0,0},
  {1,1,0,0},
  {0,1,0,0},
  {0,1,1,0},
  {0,0,1,0},
  {0,0,1,1},
  {0,0,0,1},
  {1,0,0,1}
};

#define STEP_INTERVAL_US  1400UL

#define MAX_QUEUE 30
Command cmdQueue[MAX_QUEUE];
volatile int qHead = 0, qTail = 0;

bool enqueue(const Command &cmd) {
  int next = (qTail + 1) % MAX_QUEUE;
  if (next == qHead) return false;
  cmdQueue[qTail] = cmd;
  qTail = next;
  return true;
}

bool dequeue(Command &cmd) {
  if (qHead == qTail) return false;
  cmd = cmdQueue[qHead];
  qHead = (qHead + 1) % MAX_QUEUE;
  return true;
}

Dir     currentDir     = STOP;
int     stepsRemaining = 0;
int8_t  idxA           = 0;
int8_t  idxB           = 0;
unsigned long lastStepUs = 0;

#define MAX_HISTORY 100
Command history[MAX_HISTORY];
int     historyCount = 0;

float lastYaw = 0, lastLat = 0, lastLng = 0, lastSpeed = 0;

void applyPhaseA(int8_t idx) {
  for (int i = 0; i < 4; i++)
    digitalWrite(A_PINS[i], HALF_STEP[idx][i]);
}

void applyPhaseB(int8_t idx) {
  for (int i = 0; i < 4; i++)
    digitalWrite(B_PINS[i], HALF_STEP[idx][i]);
}

void motorsOff() {
  for (int i = 0; i < 4; i++) {
    digitalWrite(A_PINS[i], LOW);
    digitalWrite(B_PINS[i], LOW);
  }
}

void stepMotors() {
  switch (currentDir) {
    case FWD:
      idxA = (idxA + 1 + 8) % 8;
      idxB = (idxB + 1 + 8) % 8;
      applyPhaseA(idxA);
      applyPhaseB(idxB);
      break;
    case BWD:
      idxA = (idxA - 1 + 8) % 8;
      idxB = (idxB - 1 + 8) % 8;
      applyPhaseA(idxA);
      applyPhaseB(idxB);
      break;
    case LEFT:
      idxA = (idxA - 1 + 8) % 8;
      idxB = (idxB + 1 + 8) % 8;
      applyPhaseA(idxA);
      applyPhaseB(idxB);
      break;
    case RIGHT:
      idxA = (idxA + 1 + 8) % 8;
      idxB = (idxB - 1 + 8) % 8;
      applyPhaseA(idxA);
      applyPhaseB(idxB);
      break;
    default:
      break;
  }
}

void startCommand(const Command &cmd) {
  currentDir     = cmd.dir;
  stepsRemaining = cmd.steps;
  if (currentDir == STOP) {
    stepsRemaining = 0;
    motorsOff();
    return;
  }
  if (cmd.steps > 0 && historyCount < MAX_HISTORY) {
    history[historyCount++] = cmd;
  }
}

void replayRoute() {
  for (int i = historyCount - 1; i >= 0; i--) {
    Command rev = history[i];
    if      (rev.dir == FWD)   rev.dir = BWD;
    else if (rev.dir == BWD)   rev.dir = FWD;
    else if (rev.dir == LEFT)  rev.dir = RIGHT;
    else if (rev.dir == RIGHT) rev.dir = LEFT;
    enqueue(rev);
  }
}

void runMotion() {
  if (stepsRemaining <= 0) {
    Command next;
    if (dequeue(next)) {
      startCommand(next);
    } else {
      if (currentDir != STOP) {
        currentDir = STOP;
        motorsOff();
      }
    }
    return;
  }

  unsigned long now = micros();
  if (now - lastStepUs >= STEP_INTERVAL_US) {
    lastStepUs = now;
    stepMotors();
    stepsRemaining--;
    if (stepsRemaining == 0) {
      currentDir = STOP;
      motorsOff();
    }
  }
}

void onReceive(const uint8_t *mac, const uint8_t *data, int len) {
  if (len != sizeof(Command)) return;

  Command cmd;
  memcpy(&cmd, data, sizeof(cmd));

  lastYaw   = cmd.yaw;
  lastLat   = cmd.lat;
  lastLng   = cmd.lng;
  lastSpeed = cmd.speed;

  Serial.printf("RX | dir:%d steps:%d yaw:%.1f lat:%.5f lng:%.5f spd:%.1f\n",
    cmd.dir, cmd.steps, cmd.yaw, cmd.lat, cmd.lng, cmd.speed);

  if (cmd.steps == -1) {
    replayRoute();
    return;
  }
  if (cmd.steps == -2) {
    historyCount = 0;
    qHead = qTail = 0;
    currentDir = STOP;
    stepsRemaining = 0;
    motorsOff();
    Serial.println("History + queue cleared");
    return;
  }
  if (cmd.dir == STOP) {
    qHead = qTail = 0;
    currentDir = STOP;
    stepsRemaining = 0;
    motorsOff();
    return;
  }

  if (stepsRemaining == 0) {
    startCommand(cmd);
  } else {
    enqueue(cmd);
  }
}

void setup() {
  Serial.begin(115200);

  for (int i = 0; i < 4; i++) {
    pinMode(A_PINS[i], OUTPUT);
    pinMode(B_PINS[i], OUTPUT);
  }
  motorsOff();

  WiFi.mode(WIFI_STA);
  Serial.print("Motor ESP32 MAC: ");
  Serial.println(WiFi.macAddress());

  if (esp_now_init() != ESP_OK) {
    Serial.println("ESP-NOW init FAILED — halting");
    while (true) delay(1000);
  }
  esp_now_register_recv_cb(onReceive);

  Serial.println("Motor ESP32 ready. Waiting for commands...");
}

void loop() {
  runMotion();
}
